package packJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Book {
    private static final String URL = "jdbc:mysql://localhost:3306/biblio";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    public static void main(String[] args) {
        biblioConnect();

        System.out.println("a. Affichage de tous les enregistrements de la table book :");
        bookDisplay();

        System.out.println("\nb. Ajout d'un nouveau book :");
        bookAdd("Nouveau Livre", "Nouvel Auteur", 2024);

        System.out.println("\nc. Affichage du nouveau book ajouté :");
        bookFind("Nouveau Livre");

        System.out.println("\nd. Modification du prix du book :");
        bookUpdate("Nouveau Titre", "Nouvel Auteur", 2024, "Nouveau Livre");

        System.out.println("\ne. Suppression d'un book :");
        bookDelete("Nouveau Titre");
    }


    public static void biblioConnect() {
        try {
            Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Connexion à la base de données établie !");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la connexion à la base de données : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void bookDisplay() {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM book");
            ResultSet resultSet = statement.executeQuery();

            System.out.println("Liste des livres :");
            while (resultSet.next()) {
                System.out.println(resultSet.getString("title") + " - " +
                                   resultSet.getString("author") + " - " +
                                   resultSet.getInt("year"));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'affichage des livres : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void bookFind(String title) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM book WHERE title = ?");
            statement.setString(1, title);
            ResultSet resultSet = statement.executeQuery();

            System.out.println("Résultat de la recherche pour '" + title + "' :");
            while (resultSet.next()) {
                System.out.println(resultSet.getString("title") + " - " +
                                   resultSet.getString("author") + " - " +
                                   resultSet.getInt("year"));
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la recherche du livre : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void bookAdd(String title, String author, int year) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO book (title, author, year) VALUES (?, ?, ?)");
            statement.setString(1, title);
            statement.setString(2, author);
            statement.setInt(3, year);
            int rowsAffected = statement.executeUpdate();

            System.out.println(rowsAffected + " livre(s) ajouté(s) avec succès !");
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout du livre : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void bookUpdate(String newTitle, String newAuthor, int newYear, String oldTitle) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            PreparedStatement statement = connection.prepareStatement("UPDATE book SET title = ?, author = ?, year = ? WHERE title = ?");
            statement.setString(1, newTitle);
            statement.setString(2, newAuthor);
            statement.setInt(3, newYear);
            statement.setString(4, oldTitle);
            int rowsAffected = statement.executeUpdate();

            System.out.println(rowsAffected + " livre(s) modifié(s) avec succès !");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la modification du livre : " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void bookDelete(String title) {
        try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM book WHERE title = ?");
            statement.setString(1, title);
            int rowsAffected = statement.executeUpdate();

            System.out.println(rowsAffected + " livre(s) supprimé(s) avec succès !");
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression du livre : " + e.getMessage());
            e.printStackTrace();
        }
    }
}
