package packDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookDaoImpl implements BookDao {
    private Connection connection;

    public BookDaoImpl() {
        connection = ConnectionFactory.getConnection();
    }

    @Override
    public void addBook(BookBean book) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO book (title, author, price) VALUES (?, ?, ?)");
            preparedStatement.setString(1, book.getTitle());
            preparedStatement.setString(2, book.getAuthor());
            preparedStatement.setFloat(3, book.getPrice());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void updateBook(BookBean book) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE book SET title=?, author=?, price=? WHERE book_id=?");
            preparedStatement.setString(1, book.getTitle());
            preparedStatement.setString(2, book.getAuthor());
            preparedStatement.setFloat(3, book.getPrice());
            preparedStatement.setLong(4, book.getBook_id());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteBook(long book_id) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM book WHERE book_id=?");
            preparedStatement.setLong(1, book_id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<BookBean> displayAll() {
        List<BookBean> books = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM book");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                BookBean book = new BookBean();
                book.setBook_id(resultSet.getLong("book_id"));
                book.setTitle(resultSet.getString("title"));
                book.setAuthor(resultSet.getString("author"));
                book.setPrice(resultSet.getFloat("price"));
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    @Override
    public List<BookBean> findBook(String kw) {
        List<BookBean> books = new ArrayList<>();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM book WHERE title LIKE ?");
            preparedStatement.setString(1, "%" + kw + "%");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                BookBean book = new BookBean();
                book.setBook_id(resultSet.getLong("book_id"));
                book.setTitle(resultSet.getString("title"));
                book.setAuthor(resultSet.getString("author"));
                book.setPrice(resultSet.getFloat("price"));
                books.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }
}
