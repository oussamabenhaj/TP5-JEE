package packDAO;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        BookDao bookDao = new BookDaoImpl();

        System.out.println("Tous les livres : ");
        List<BookBean> allBooks = bookDao.displayAll();
        for (BookBean book : allBooks) {
            System.out.println(book.getTitle() + " par " + book.getAuthor() + " - Prix : " + book.getPrice());
        }

        BookBean newBook = new BookBean();
        newBook.setTitle("Nouveau Livre");
        newBook.setAuthor("Auteur Inconnu");
        newBook.setPrice(19.99f);
        bookDao.addBook(newBook);

        System.out.println("\nNouveau Livre ajouté : ");
        List<BookBean> foundBooks = bookDao.findBook("Nouveau");
        for (BookBean book : foundBooks) {
            System.out.println(book.getTitle() + " par " + book.getAuthor() + " - Prix : " + book.getPrice());
        }

        if (!foundBooks.isEmpty()) {
            BookBean bookToUpdate = foundBooks.get(0);
            bookToUpdate.setPrice(24.99f);
            bookDao.updateBook(bookToUpdate);
        }

        if (!foundBooks.isEmpty()) {
            BookBean bookToDelete = foundBooks.get(0);
            long book_id = bookToDelete.getBook_id();
            bookDao.deleteBook(book_id);
            System.out.println("\nLivre supprimé avec succès.");
        }
    }
}
